!======================================================================
! GPU CUDA implementation via OpenMP Target Offload
! Replaces OpenACC with OpenMP 4.5+ target directives.
!
! Compile with:
!   gfortran -fopenmp -foffload=nvptx-none -foffload-options="-O3 -misa=sm_35"
!   or with NVHPC:
!   nvfortran -mp=gpu -gpu=cc80
!
! This module provides:
!   1. GPU device management (init/finalize)
!   2. Data transfer utilities (host->device, device->host)
!   3. Inline !$omp target directives in compute routines
!======================================================================

module gpu_cuda_kernels
  use iso_fortran_env, only: real32, int32
  implicit none

  logical, save :: gpu_initialized = .false.
  integer, save :: gpu_device_num  = 0
  logical, save :: use_gpu         = .false.

  interface gpu_copy_to_device
    module procedure gpu_copy_to_device_2d
    module procedure gpu_copy_to_device_3d
  end interface

  interface gpu_copy_to_host
    module procedure gpu_copy_to_host_2d
    module procedure gpu_copy_to_host_3d
  end interface

contains

  !--------------------------------------------------------------------
  ! Initialize GPU device
  !--------------------------------------------------------------------
  subroutine gpu_init(device_num)
    integer, intent(in), optional :: device_num
    integer :: num_devices, dev

    if (present(device_num)) then
      dev = device_num
    else
      dev = 0
    end if

    !$omp target
    !$omp end target
    gpu_initialized = .true.
    use_gpu = .true.
    gpu_device_num = dev

    write(*,'(A,I3,A)') ' [GPU] OpenMP target offload initialized on device', &
                         dev, ' (CUDA via nvptx offload)'
  end subroutine gpu_init

  !--------------------------------------------------------------------
  ! Finalize GPU device  
  !--------------------------------------------------------------------
  subroutine gpu_finalize()
    if (gpu_initialized) then
      write(*,'(A)') ' [GPU] Finalizing GPU device'
      gpu_initialized = .false.
      use_gpu = .false.
    end if
  end subroutine gpu_finalize

  !--------------------------------------------------------------------
  ! Copy 2D array host -> device
  !--------------------------------------------------------------------
  subroutine gpu_copy_to_device_2d(arr, nx, ny)
    real(real32), intent(inout) :: arr(nx,ny)
    integer, intent(in) :: nx, ny
    !$omp target enter data map(to: arr)
  end subroutine gpu_copy_to_device_2d

  !--------------------------------------------------------------------
  ! Copy 3D array host -> device
  !--------------------------------------------------------------------
  subroutine gpu_copy_to_device_3d(arr, nx, ny, nz)
    real(real32), intent(inout) :: arr(nx,ny,nz)
    integer, intent(in) :: nx, ny, nz
    !$omp target enter data map(to: arr)
  end subroutine gpu_copy_to_device_3d

  !--------------------------------------------------------------------
  ! Copy 2D array device -> host
  !--------------------------------------------------------------------
  subroutine gpu_copy_to_host_2d(arr, nx, ny)
    real(real32), intent(inout) :: arr(nx,ny)
    integer, intent(in) :: nx, ny
    !$omp target exit data map(from: arr)
  end subroutine gpu_copy_to_host_2d

  !--------------------------------------------------------------------
  ! Copy 3D array device -> host
  !--------------------------------------------------------------------
  subroutine gpu_copy_to_host_3d(arr, nx, ny, nz)
    real(real32), intent(inout) :: arr(nx,ny,nz)
    integer, intent(in) :: nx, ny, nz
    !$omp target exit data map(from: arr)
  end subroutine gpu_copy_to_host_3d

  !--------------------------------------------------------------------
  ! GPU kernel: Set vertical grid depths (set_depth equivalent)
  ! Computes z_w, z_r, Hz arrays on GPU
  !--------------------------------------------------------------------
  subroutine gpu_kernel_set_depth(Istr, Iend, Jstr, Jend, N,         &
                                   h, hinv, zeta, Zt_avg1,            &
                                   sc_w, sc_r, Cs_w, Cs_r,            &
                                   hc, z_w, z_r, Hz, Hz_bak,          &
                                   Lm, Mm)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, N, Lm, Mm
    real(real32), intent(in)    :: hc
    real(real32), intent(in)    :: h(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)    :: hinv(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)    :: zeta(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)    :: Zt_avg1(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)    :: sc_w(0:N), sc_r(N)
    real(real32), intent(in)    :: Cs_w(0:N), Cs_r(N)
    real(real32), intent(inout) :: z_w(0:Lm+1, 0:Mm+1, 0:N)
    real(real32), intent(inout) :: z_r(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: Hz(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: Hz_bak(0:Lm+1, 0:Mm+1, N)

    integer :: i, j, k
    real(real32) :: cff_w, cff_r, cff1_w, cff1_r
    real(real32) :: zetatmp, htmp, z_w0, z_r0

    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: h, hinv, Zt_avg1, sc_w, sc_r, Cs_w, Cs_r) &
    !$omp& map(from: z_w, z_r, Hz, Hz_bak) &
    !$omp& private(k, cff_w, cff_r, cff1_w, cff1_r, zetatmp, htmp, z_w0, z_r0)
    do j = Jstr, Jend
      do i = Istr, Iend
        ! Bottom boundary
        z_w(i,j,0) = -h(i,j)

        do k = 1, N
          ! NEW_S_COORD formulation
          cff_w  = hc * sc_w(k)
          cff_r  = hc * sc_r(k)
          cff1_w = Cs_w(k)
          cff1_r = Cs_r(k)

          zetatmp = Zt_avg1(i,j)
          htmp    = abs(h(i,j))

          z_w0 = cff_w + cff1_w * htmp
          z_r0 = cff_r + cff1_r * htmp

          z_w(i,j,k) = z_w0 * h(i,j) * hinv(i,j) + zetatmp &
                      * (1.0 + z_w0 * hinv(i,j))
          z_r(i,j,k) = z_r0 * h(i,j) * hinv(i,j) + zetatmp &
                      * (1.0 + z_r0 * hinv(i,j))

          ! Compute layer thickness
          Hz_bak(i,j,k) = Hz(i,j,k)
          Hz(i,j,k)     = z_w(i,j,k) - z_w(i,j,k-1)
        end do
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_set_depth

  !--------------------------------------------------------------------
  ! GPU kernel: Density (equation of state) - rho_eos equivalent
  ! UNESCO/TEOS-10 equation of state
  !--------------------------------------------------------------------
  subroutine gpu_kernel_rho_eos(Istr, Iend, Jstr, Jend, N,           &
                                  t_tracer, rho, bvf,                   &
                                  z_r, z_w, Hz,                         &
                                  rho0, g, Lm, Mm, NT)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, N, Lm, Mm, NT
    real(real32), intent(in)    :: rho0, g
    real(real32), intent(in)    :: t_tracer(0:Lm+1, 0:Mm+1, N, 3, NT)
    real(real32), intent(in)    :: z_r(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(in)    :: z_w(0:Lm+1, 0:Mm+1, 0:N)
    real(real32), intent(in)    :: Hz(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: rho(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: bvf(0:Lm+1, 0:Mm+1, 0:N)

    ! UNESCO equation of state coefficients
    real(real32), parameter :: &
      A00 = +19092.56_real32,  A01 = +209.8925_real32,   &
      A02 = -3.041638_real32,  A03 = -1.852732e-3_real32, &
      A04 = -1.361629e-5_real32, B00 = 104.4077_real32,  &
      B01 = -6.500517_real32,  B02 = +0.1553190_real32,  &
      B03 = -2.326469e-4_real32, D00 = -5765.538_real32, &
      D01 = -113.9238_real32,  D02 = +1.250888_real32,   &
      E00 = +752.6163_real32,  E01 = +2.699143e1_real32, &
      E02 = -3.10527e-1_real32, F00 = +2.283697e1_real32, &
      F01 = -1.360229e-2_real32, G00 = +4.950979e-1_real32, &
      G01 = -1.844796e-4_real32, Q00 = +999.842594_real32, &
      Q01 = +6.793952e-2_real32, Q02 = -9.095290e-3_real32, &
      Q03 = +1.001685e-4_real32, Q04 = -1.120083e-6_real32, &
      Q05 = +6.536332e-9_real32, U00 = +0.824493_real32, &
      U01 = -4.08990e-3_real32, U02 = +7.64380e-5_real32, &
      U03 = -8.24670e-7_real32, U04 = +5.38750e-9_real32, &
      V00 = -5.72466e-3_real32, V01 = +1.02270e-4_real32, &
      V02 = -1.65460e-6_real32, W00 = +4.8314e-4_real32

    integer  :: i, j, k
    real(real32) :: Tt, Ts, sqrtTs, rho1, cff, bulk

    !$omp target teams distribute parallel do collapse(3) &
    !$omp& map(to: t_tracer, z_r, z_w, Hz) &
    !$omp& map(from: rho, bvf) &
    !$omp& private(Tt, Ts, sqrtTs, rho1, cff, bulk)
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend
          Tt = t_tracer(i,j,k,1,1)    ! temperature (°C)
          Ts = max(0.0_real32, t_tracer(i,j,k,1,2))  ! salinity (PSU)
          sqrtTs = sqrt(Ts)

          ! Pure water density (Millero et al. 1981)
          rho1 = Q00 + Tt*(Q01 + Tt*(Q02 + Tt*(Q03 + Tt*(Q04 + Tt*Q05)))) &
               + Ts*(U00 + Tt*(U01 + Tt*(U02 + Tt*(U03 + Tt*U04))))        &
               + sqrtTs*(V00 + Tt*(V01 + Tt*V02))                          &
               + W00*Ts*Ts

          ! Secant bulk modulus (compression effects)
          bulk = (A00 + Tt*(A01 + Tt*(A02 + Tt*(A03 + Tt*A04)))            &
               + Ts*(B00 + Tt*(B01 + Tt*(B02 + Tt*B03)))                   &
               + sqrtTs*(D00 + Tt*(D01 + Tt*D02)))

          cff = -g * rho0 * z_r(i,j,k)
          bulk = bulk + cff * (E00 + Tt*(E01 + Tt*E02)                     &
               + Ts*(F00 + Tt*F01)                                          &
               + sqrtTs*G00                                                 &
               + cff*(G01))

          rho(i,j,k) = (rho1 * bulk) / (bulk - cff) - rho0

        end do
      end do
    end do
    !$omp end target teams distribute parallel do

    ! Brunt-Vaisala frequency
    !$omp target teams distribute parallel do collapse(3) &
    !$omp& map(to: rho, z_r, Hz) map(from: bvf)
    do k = 1, N-1
      do j = Jstr, Jend
        do i = Istr, Iend
          cff = 2.0_real32 / (Hz(i,j,k+1) + Hz(i,j,k))
          bvf(i,j,k) = -g / rho0 * cff * (rho(i,j,k+1) - rho(i,j,k))
        end do
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_rho_eos

  !--------------------------------------------------------------------
  ! GPU kernel: Horizontal tracer advection fluxes (step3d_t equivalent)
  ! Computes FX, FE flux arrays for tracer transport
  !--------------------------------------------------------------------
  subroutine gpu_kernel_horiz_tracer_flux(Istr, Iend, Jstr, Jend, N, &
                                            k_level, t_tracer,          &
                                            Huon, Hvom,                  &
                                            FX, FE,                      &
                                            Lm, Mm, NT)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, N, k_level, Lm, Mm, NT
    real(real32), intent(in)  :: t_tracer(0:Lm+1, 0:Mm+1, N, 3, NT)
    real(real32), intent(in)  :: Huon(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(in)  :: Hvom(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(out) :: FX(0:Lm+1, 0:Mm+1)
    real(real32), intent(out) :: FE(0:Lm+1, 0:Mm+1)

    integer :: i, j, itrc
    real(real32) :: cff
    integer, parameter :: nstp = 1   ! time index for source

    itrc = 1  ! first tracer (temperature)

    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: t_tracer, Huon, Hvom) map(from: FX, FE)
    do j = Jstr-1, Jend
      do i = Istr-1, Iend+1
        ! X-flux (centered scheme)
        cff = 0.5_real32 * Huon(i,j,k_level)
        FX(i,j) = cff * (t_tracer(i-1,j,k_level,nstp,itrc)   &
                        + t_tracer(i,  j,k_level,nstp,itrc))

        ! Y-flux (centered scheme)
        cff = 0.5_real32 * Hvom(i,j,k_level)
        FE(i,j) = cff * (t_tracer(i,j-1,k_level,nstp,itrc)   &
                        + t_tracer(i,j,  k_level,nstp,itrc))
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_horiz_tracer_flux

  !--------------------------------------------------------------------
  ! GPU kernel: Vertical mixing (tridiagonal solver)
  ! Implicit vertical diffusion on GPU
  !--------------------------------------------------------------------
  subroutine gpu_kernel_vert_mix(Istr, Iend, Jstr, Jend, N,          &
                                   t_tracer, Hz, Akt, dt,               &
                                   Lm, Mm, NT)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, N, Lm, Mm, NT
    real(real32), intent(in)    :: dt
    real(real32), intent(in)    :: Hz(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(in)    :: Akt(0:Lm+1, 0:Mm+1, 0:N)
    real(real32), intent(inout) :: t_tracer(0:Lm+1, 0:Mm+1, N, 3, NT)

    integer :: i, j, k, itrc
    real(real32) :: FC(0:N), DC(N), BC(N), CF(N)
    real(real32) :: cff, cff1

    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: Hz, Akt) map(tofrom: t_tracer) &
    !$omp& private(k, itrc, FC, DC, BC, CF, cff, cff1)
    do j = Jstr, Jend
      do i = Istr, Iend
        do itrc = 1, NT
          ! Build tridiagonal system
          do k = 1, N-1
            cff  = 2.0_real32 * Akt(i,j,k) / (Hz(i,j,k) + Hz(i,j,k+1))
            FC(k) = dt * cff
          end do
          FC(0) = 0.0_real32
          FC(N) = 0.0_real32

          ! Forward sweep
          BC(1) = Hz(i,j,1) + FC(1)
          CF(1) = FC(1) / BC(1)
          do k = 2, N
            BC(k) = Hz(i,j,k) + FC(k) + FC(k-1) * (1.0_real32 - CF(k-1))
            CF(k) = FC(k) / BC(k)
          end do

          ! Backward substitution
          DC(N) = t_tracer(i,j,N,1,itrc) * Hz(i,j,N) / BC(N)
          do k = N-1, 1, -1
            DC(k) = (t_tracer(i,j,k,1,itrc)*Hz(i,j,k) + FC(k-1)*DC(k+1)) / BC(k)
          end do
          do k = 2, N
            DC(k) = DC(k) + CF(k-1) * DC(k-1)
          end do

          ! Update tracer (nnew = 3)
          do k = 1, N
            t_tracer(i,j,k,3,itrc) = DC(k)
          end do
        end do
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_vert_mix

  !--------------------------------------------------------------------
  ! GPU kernel: Pressure gradient force (prsgrd equivalent)
  ! Density-Jacobian pressure gradient
  !--------------------------------------------------------------------
  subroutine gpu_kernel_prsgrd(Istr, Iend, Jstr, Jend, N,             &
                                 rho, z_r, Hz, ru, rv,                   &
                                 rho0, g, Lm, Mm)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, N, Lm, Mm
    real(real32), intent(in)    :: rho0, g
    real(real32), intent(in)    :: rho(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(in)    :: z_r(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(in)    :: Hz(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: ru(0:Lm+1, 0:Mm+1, N)
    real(real32), intent(inout) :: rv(0:Lm+1, 0:Mm+1, N)

    integer :: i, j, k
    real(real32) :: cff, cff1, gz_r, gz_l

    !$omp target teams distribute parallel do collapse(3) &
    !$omp& map(to: rho, z_r, Hz) map(tofrom: ru, rv) &
    !$omp& private(cff, cff1, gz_r, gz_l)
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend+1
          cff  = g / rho0
          gz_r = cff * rho(i,  j,k) * (z_r(i,  j,k) - z_r(i-1,j,k))
          gz_l = cff * rho(i-1,j,k) * (z_r(i,  j,k) - z_r(i-1,j,k))
          cff1 = 0.5_real32 * (Hz(i,j,k) + Hz(i-1,j,k))
          ru(i,j,k) = ru(i,j,k) - cff1 * (gz_r + gz_l)
        end do
      end do
    end do
    !$omp end target teams distribute parallel do

    !$omp target teams distribute parallel do collapse(3) &
    !$omp& map(to: rho, z_r, Hz) map(tofrom: rv) &
    !$omp& private(cff, cff1, gz_r, gz_l)
    do k = 1, N
      do j = Jstr, Jend+1
        do i = Istr, Iend
          cff  = g / rho0
          gz_r = cff * rho(i,j,  k) * (z_r(i,j,  k) - z_r(i,j-1,k))
          gz_l = cff * rho(i,j-1,k) * (z_r(i,j,  k) - z_r(i,j-1,k))
          cff1 = 0.5_real32 * (Hz(i,j,k) + Hz(i,j-1,k))
          rv(i,j,k) = rv(i,j,k) - cff1 * (gz_r + gz_l)
        end do
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_prsgrd

  !--------------------------------------------------------------------
  ! GPU kernel: 2D barotropic step (step2d equivalent)
  ! Leapfrog/AB3 time stepping of free surface and barotropic velocities
  !--------------------------------------------------------------------
  subroutine gpu_kernel_step2d(Istr, Iend, Jstr, Jend,               &
                                 zeta, ubar, vbar,                       &
                                 Drhs, DUon, DVom,                        &
                                 rufrc, rvfrc,                            &
                                 pm, pn, dt2d,                           &
                                 Lm, Mm)
    implicit none
    integer, intent(in) :: Istr, Iend, Jstr, Jend, Lm, Mm
    real(real32), intent(in)  :: dt2d
    real(real32), intent(in)  :: pm(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)  :: pn(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)  :: DUon(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)  :: DVom(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)  :: rufrc(0:Lm+1, 0:Mm+1)
    real(real32), intent(in)  :: rvfrc(0:Lm+1, 0:Mm+1)
    real(real32), intent(inout) :: zeta(0:Lm+1, 0:Mm+1, 4)
    real(real32), intent(inout) :: ubar(0:Lm+1, 0:Mm+1, 3)
    real(real32), intent(inout) :: vbar(0:Lm+1, 0:Mm+1, 3)
    real(real32), intent(inout) :: Drhs(0:Lm+1, 0:Mm+1)

    integer :: i, j

    ! Update free surface: continuity equation
    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: pm, pn, DUon, DVom) map(tofrom: zeta, Drhs)
    do j = Jstr, Jend
      do i = Istr, Iend
        zeta(i,j,3) = zeta(i,j,1) - dt2d * pm(i,j) * pn(i,j) * &
                      (DUon(i+1,j) - DUon(i,j) + DVom(i,j+1) - DVom(i,j))
        Drhs(i,j) = zeta(i,j,3) + 1.0_real32  ! depth at new time
      end do
    end do
    !$omp end target teams distribute parallel do

    ! Update barotropic u-velocity
    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: pm, pn, Drhs, rufrc) map(tofrom: ubar)
    do j = Jstr, Jend
      do i = Istr, Iend+1
        ubar(i,j,3) = ubar(i,j,1) + dt2d * rufrc(i,j)
      end do
    end do
    !$omp end target teams distribute parallel do

    ! Update barotropic v-velocity
    !$omp target teams distribute parallel do collapse(2) &
    !$omp& map(to: pm, pn, Drhs, rvfrc) map(tofrom: vbar)
    do j = Jstr, Jend+1
      do i = Istr, Iend
        vbar(i,j,3) = vbar(i,j,1) + dt2d * rvfrc(i,j)
      end do
    end do
    !$omp end target teams distribute parallel do

  end subroutine gpu_kernel_step2d

end module gpu_cuda_kernels
