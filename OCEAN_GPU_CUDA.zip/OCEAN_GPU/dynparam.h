!======================================================================
! CROCO is a branch of ROMS developped at IRD, INRIA, 
! Ifremer, CNRS and Univ. Toulouse III  in France
! The two other branches from UCLA (Shchepetkin et al)
! and Rutgers University (Arango et al) are under MIT/X style license.
! CROCO specific routines (nesting) are under CeCILL-C license.
!
! CROCO website : http://www.croco-ocean.org
!======================================================================
!
! Dimensions of Physical Grid and array dimensions:
! =========== == ======== ==== === ===== ============
! LLm,MMm  Number of the internal points of the PHYSICAL grid.
!          in the XI- and ETA-directions [physical side boundary
!          points and peroodic ghost points (if any) are excluded].
!
! Lm,Mm    Number of the internal points [see above] of array
!          covering a Message Passing subdomain. In the case when
!          no Message Passing partitioning is used, these two are
!          the same as LLm,MMm.
!
! Declarations moved here from dynderivparam.h so they appear before
! any executable statements (required by Fortran and AGRIF converter):
#if defined AGRIF
      integer size_XI, size_ETA, se, sse, sz, ssz
      integer N2dabl, N3dabl
#endif
      LLm=LLm0;  MMm=MMm0      ! LLm0,MMm0 defined in param.h
