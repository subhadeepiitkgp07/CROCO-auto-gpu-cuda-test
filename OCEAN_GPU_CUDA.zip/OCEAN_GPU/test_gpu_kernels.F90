!======================================================================
! GPU CUDA Kernel Test Suite for CROCO Ocean Model
! Tests each GPU kernel against CPU reference implementation
! Compile: gfortran -fopenmp -foffload=nvptx-none -O2 test_gpu_kernels.F90
!          gpu_cuda_kernels.F90 -o test_gpu
! Run:     ./test_gpu
!======================================================================

program test_gpu_kernels
  use gpu_cuda_kernels
  use iso_fortran_env, only: real32, real64
  implicit none

  integer :: pass_count, fail_count, total_tests
  real(real64) :: t_start, t_end, t_cpu, t_gpu
  logical :: test_ok

  pass_count = 0
  fail_count = 0
  total_tests = 0

  write(*,'(A)') ''
  write(*,'(A)') '============================================================'
  write(*,'(A)') ' CROCO Ocean Model - GPU CUDA Kernel Test Suite'
  write(*,'(A)') ' Implementation: OpenMP 4.5+ Target Offload (nvptx/CUDA)'
  write(*,'(A)') '============================================================'
  write(*,'(A)') ''

  ! Initialize GPU
  call gpu_init(0)
  write(*,'(A)') ''

  ! ---- Test 1: Set Depth Kernel ----
  write(*,'(A)') '[TEST 1] gpu_kernel_set_depth: Vertical grid computation'
  call test_set_depth(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 2: Equation of State (rho_eos) ----
  write(*,'(A)') '[TEST 2] gpu_kernel_rho_eos: UNESCO equation of state'
  call test_rho_eos(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 3: Horizontal Tracer Flux ----
  write(*,'(A)') '[TEST 3] gpu_kernel_horiz_tracer_flux: Tracer advection fluxes'
  call test_horiz_tracer(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 4: Vertical Mixing (tridiagonal solver) ----
  write(*,'(A)') '[TEST 4] gpu_kernel_vert_mix: Implicit vertical diffusion'
  call test_vert_mix(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 5: Pressure Gradient Force ----
  write(*,'(A)') '[TEST 5] gpu_kernel_prsgrd: Density-Jacobian pressure gradient'
  call test_prsgrd(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 6: 2D Barotropic Step ----
  write(*,'(A)') '[TEST 6] gpu_kernel_step2d: Barotropic free-surface step'
  call test_step2d(test_ok, t_cpu, t_gpu)
  call record_result(test_ok, pass_count, fail_count, total_tests)
  write(*,'(A,F8.3,A,F8.3,A,F6.2,A)') '         CPU: ', t_cpu*1e3, ' ms | GPU: ', &
    t_gpu*1e3, ' ms | Speedup: ', t_cpu/max(t_gpu,1e-9), 'x'
  write(*,'(A)') ''

  ! ---- Test 7: Performance Benchmark (realistic ocean domain) ----
  write(*,'(A)') '[TEST 7] Performance Benchmark: 256x256x50 ocean grid'
  call test_benchmark_full(t_cpu, t_gpu)
  write(*,'(A)') ''

  ! Finalize
  call gpu_finalize()

  ! Summary
  write(*,'(A)') '============================================================'
  write(*,'(A,I3,A,I3,A,I3,A)') ' Results: ', pass_count, ' passed, ', &
    fail_count, ' failed out of ', total_tests, ' tests'
  if (fail_count == 0) then
    write(*,'(A)') ' STATUS: ALL TESTS PASSED ✓'
  else
    write(*,'(A)') ' STATUS: SOME TESTS FAILED ✗'
  end if
  write(*,'(A)') '============================================================'

contains

  !------------------------------------------------------------------
  ! Utility: record pass/fail
  !------------------------------------------------------------------
  subroutine record_result(ok, pass_c, fail_c, total_c)
    logical, intent(in) :: ok
    integer, intent(inout) :: pass_c, fail_c, total_c
    total_c = total_c + 1
    if (ok) then
      pass_c = pass_c + 1
      write(*,'(A)') '         STATUS: PASS ✓'
    else
      fail_c = fail_c + 1
      write(*,'(A)') '         STATUS: FAIL ✗'
    end if
  end subroutine

  !------------------------------------------------------------------
  ! Wall-clock timer
  !------------------------------------------------------------------
  subroutine wall_time(t)
    real(real64), intent(out) :: t
    integer :: c, r
    call system_clock(c, r)
    t = real(c, real64) / real(r, real64)
  end subroutine

  !------------------------------------------------------------------
  ! Test 1: Set Depth
  !------------------------------------------------------------------
  subroutine test_set_depth(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=63, Mm=63, N=30
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: h(:,:), hinv(:,:), zeta(:,:), Zt_avg1(:,:)
    real(real32), allocatable :: sc_w(:), sc_r(:), Cs_w(:), Cs_r(:)
    real(real32), allocatable :: z_w_gpu(:,:,:), z_r_gpu(:,:,:)
    real(real32), allocatable :: Hz_gpu(:,:,:), Hz_bak_gpu(:,:,:)
    real(real32), allocatable :: z_w_ref(:,:,:), z_r_ref(:,:,:)
    real(real32), allocatable :: Hz_ref(:,:,:), Hz_bak_ref(:,:,:)
    real(real32) :: hc
    integer :: i, j, k
    real(real64) :: t1, t2
    real(real32) :: max_err

    allocate(h(0:Lm+1,0:Mm+1), hinv(0:Lm+1,0:Mm+1))
    allocate(zeta(0:Lm+1,0:Mm+1), Zt_avg1(0:Lm+1,0:Mm+1))
    allocate(sc_w(0:N), sc_r(N), Cs_w(0:N), Cs_r(N))
    allocate(z_w_gpu(0:Lm+1,0:Mm+1,0:N), z_r_gpu(0:Lm+1,0:Mm+1,N))
    allocate(Hz_gpu(0:Lm+1,0:Mm+1,N), Hz_bak_gpu(0:Lm+1,0:Mm+1,N))
    allocate(z_w_ref(0:Lm+1,0:Mm+1,0:N), z_r_ref(0:Lm+1,0:Mm+1,N))
    allocate(Hz_ref(0:Lm+1,0:Mm+1,N), Hz_bak_ref(0:Lm+1,0:Mm+1,N))

    ! Initialize test data
    hc = 10.0_real32
    do j = 0, Mm+1
      do i = 0, Lm+1
        h(i,j)    = 100.0_real32 + 50.0_real32 * sin(real(i,real32)*0.1_real32)
        hinv(i,j) = 1.0_real32 / (abs(h(i,j)) + hc)
        zeta(i,j) = 0.1_real32 * cos(real(j,real32)*0.1_real32)
        Zt_avg1(i,j) = zeta(i,j)
        Hz_gpu(i,j,:)     = 3.0_real32
        Hz_bak_gpu(i,j,:) = 3.0_real32
        Hz_ref(i,j,:)     = 3.0_real32
        Hz_bak_ref(i,j,:) = 3.0_real32
      end do
    end do
    do k = 0, N
      sc_w(k) = real(k,real32)/real(N,real32) - 1.0_real32
      Cs_w(k) = sc_w(k)
    end do
    do k = 1, N
      sc_r(k) = (real(k,real32) - 0.5_real32)/real(N,real32) - 1.0_real32
      Cs_r(k) = sc_r(k)
    end do

    ! CPU reference
    call wall_time(t1)
    call cpu_set_depth_ref(Istr,Iend,Jstr,Jend,N,Lm,Mm, &
                           h,hinv,Zt_avg1,hc,sc_w,sc_r,Cs_w,Cs_r, &
                           z_w_ref,z_r_ref,Hz_ref,Hz_bak_ref)
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel
    call wall_time(t1)
    call gpu_kernel_set_depth(Istr,Iend,Jstr,Jend,N, &
                               h,hinv,Zt_avg1,Zt_avg1, &
                               sc_w,sc_r,Cs_w,Cs_r,hc, &
                               z_w_gpu,z_r_gpu,Hz_gpu,Hz_bak_gpu,Lm,Mm)
    call wall_time(t2)
    t_gpu = t2 - t1

    ! Compare results
    max_err = 0.0_real32
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend
          max_err = max(max_err, abs(z_r_gpu(i,j,k) - z_r_ref(i,j,k)))
          max_err = max(max_err, abs(Hz_gpu(i,j,k)  - Hz_ref(i,j,k)))
        end do
      end do
    end do
    write(*,'(A,E10.3)') '         Max error vs CPU reference: ', max_err
    ok = (max_err < 1.0e-4_real32)

    deallocate(h, hinv, zeta, Zt_avg1, sc_w, sc_r, Cs_w, Cs_r)
    deallocate(z_w_gpu, z_r_gpu, Hz_gpu, Hz_bak_gpu)
    deallocate(z_w_ref, z_r_ref, Hz_ref, Hz_bak_ref)
  end subroutine test_set_depth

  !------------------------------------------------------------------
  ! CPU reference for set_depth
  !------------------------------------------------------------------
  subroutine cpu_set_depth_ref(Istr,Iend,Jstr,Jend,N,Lm,Mm, &
                                h,hinv,Zt_avg1,hc,sc_w,sc_r,Cs_w,Cs_r, &
                                z_w,z_r,Hz,Hz_bak)
    integer, intent(in) :: Istr,Iend,Jstr,Jend,N,Lm,Mm
    real(real32), intent(in) :: hc
    real(real32), intent(in) :: h(0:Lm+1,0:Mm+1), hinv(0:Lm+1,0:Mm+1)
    real(real32), intent(in) :: Zt_avg1(0:Lm+1,0:Mm+1)
    real(real32), intent(in) :: sc_w(0:N), sc_r(N), Cs_w(0:N), Cs_r(N)
    real(real32), intent(out) :: z_w(0:Lm+1,0:Mm+1,0:N)
    real(real32), intent(out) :: z_r(0:Lm+1,0:Mm+1,N)
    real(real32), intent(inout) :: Hz(0:Lm+1,0:Mm+1,N)
    real(real32), intent(inout) :: Hz_bak(0:Lm+1,0:Mm+1,N)
    integer :: i,j,k
    real(real32) :: cff_w, cff_r, cff1_w, cff1_r, htmp, zetatmp, z_w0, z_r0

    do j = Jstr, Jend
      do i = Istr, Iend
        z_w(i,j,0) = -h(i,j)
        do k = 1, N
          cff_w  = hc*sc_w(k)
          cff_r  = hc*sc_r(k)
          cff1_w = Cs_w(k)
          cff1_r = Cs_r(k)
          zetatmp = Zt_avg1(i,j)
          htmp    = abs(h(i,j))
          z_w0    = cff_w + cff1_w*htmp
          z_r0    = cff_r + cff1_r*htmp
          z_w(i,j,k) = z_w0*h(i,j)*hinv(i,j) + zetatmp*(1.+z_w0*hinv(i,j))
          z_r(i,j,k) = z_r0*h(i,j)*hinv(i,j) + zetatmp*(1.+z_r0*hinv(i,j))
          Hz_bak(i,j,k) = Hz(i,j,k)
          Hz(i,j,k) = z_w(i,j,k) - z_w(i,j,k-1)
        end do
      end do
    end do
  end subroutine cpu_set_depth_ref

  !------------------------------------------------------------------
  ! Test 2: rho_eos
  !------------------------------------------------------------------
  subroutine test_rho_eos(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=63, Mm=63, N=30, NT=2
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: t_tr(:,:,:,:,:)
    real(real32), allocatable :: z_r(:,:,:), z_w(:,:,:), Hz(:,:,:)
    real(real32), allocatable :: rho_gpu(:,:,:), bvf_gpu(:,:,:)
    real(real32), allocatable :: rho_ref(:,:,:), bvf_ref(:,:,:)
    real(real32) :: rho0, g
    integer :: i, j, k
    real(real64) :: t1, t2
    real(real32) :: max_err

    allocate(t_tr(0:Lm+1,0:Mm+1,N,3,NT))
    allocate(z_r(0:Lm+1,0:Mm+1,N), z_w(0:Lm+1,0:Mm+1,0:N))
    allocate(Hz(0:Lm+1,0:Mm+1,N))
    allocate(rho_gpu(0:Lm+1,0:Mm+1,N), bvf_gpu(0:Lm+1,0:Mm+1,0:N))
    allocate(rho_ref(0:Lm+1,0:Mm+1,N), bvf_ref(0:Lm+1,0:Mm+1,0:N))

    rho0 = 1025.0_real32
    g    = 9.81_real32

    ! Realistic ocean initial conditions
    do k = 1, N
      do j = 0, Mm+1
        do i = 0, Lm+1
          t_tr(i,j,k,1,1) = 20.0_real32 - 15.0_real32*real(k,real32)/real(N,real32)  ! T in C
          t_tr(i,j,k,1,2) = 35.0_real32 - 2.0_real32*real(k,real32)/real(N,real32)   ! S in PSU
          z_r(i,j,k)  = -real(k,real32)*10.0_real32 + 5.0_real32
          z_w(i,j,k)  = -real(k,real32)*10.0_real32
          Hz(i,j,k)   = 10.0_real32
        end do
      end do
    end do
    z_w(:,:,0) = -300.0_real32
    bvf_gpu = 0.0_real32; bvf_ref = 0.0_real32

    ! CPU reference (simple linear EOS for testing)
    call wall_time(t1)
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend
          rho_ref(i,j,k) = -0.2_real32*(t_tr(i,j,k,1,1)-10.0_real32) &
                           +0.8_real32*(t_tr(i,j,k,1,2)-35.0_real32)
        end do
      end do
    end do
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel (full UNESCO EOS)
    call wall_time(t1)
    call gpu_kernel_rho_eos(Istr,Iend,Jstr,Jend,N, &
                             t_tr,rho_gpu,bvf_gpu, &
                             z_r,z_w,Hz,rho0,g,Lm,Mm,NT)
    call wall_time(t2)
    t_gpu = t2 - t1

    ! Validate: check rho is in physically reasonable range [-5, 35] kg/m^3 anomaly
    max_err = 0.0_real32
    ok = .true.
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend
          if (rho_gpu(i,j,k) < -10.0_real32 .or. rho_gpu(i,j,k) > 40.0_real32) then
            ok = .false.
            max_err = max(max_err, abs(rho_gpu(i,j,k)))
          end if
        end do
      end do
    end do
    write(*,'(A,F8.3,A,F8.3)') '         rho range: [', minval(rho_gpu(Istr:Iend,Jstr:Jend,:)), &
      ', ', maxval(rho_gpu(Istr:Iend,Jstr:Jend,:))
    if (ok) write(*,'(A)') '         Physical range check: OK'

    deallocate(t_tr, z_r, z_w, Hz, rho_gpu, bvf_gpu, rho_ref, bvf_ref)
  end subroutine test_rho_eos

  !------------------------------------------------------------------
  ! Test 3: Horizontal tracer flux
  !------------------------------------------------------------------
  subroutine test_horiz_tracer(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=127, Mm=127, N=40, NT=2
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: t_tr(:,:,:,:,:), Huon(:,:,:), Hvom(:,:,:)
    real(real32), allocatable :: FX_gpu(:,:), FE_gpu(:,:)
    real(real32), allocatable :: FX_ref(:,:), FE_ref(:,:)
    integer :: i, j
    real(real64) :: t1, t2
    real(real32) :: max_err
    integer, parameter :: k_lev = 10

    allocate(t_tr(0:Lm+1,0:Mm+1,N,3,NT))
    allocate(Huon(0:Lm+1,0:Mm+1,N), Hvom(0:Lm+1,0:Mm+1,N))
    allocate(FX_gpu(0:Lm+1,0:Mm+1), FE_gpu(0:Lm+1,0:Mm+1))
    allocate(FX_ref(0:Lm+1,0:Mm+1), FE_ref(0:Lm+1,0:Mm+1))

    ! Initialize
    call random_number(t_tr); t_tr = t_tr * 20.0_real32
    Huon = 100.0_real32; Hvom = 80.0_real32

    ! CPU reference: centered flux
    call wall_time(t1)
    do j = Jstr-1, Jend
      do i = Istr-1, Iend+1
        FX_ref(i,j) = 0.5_real32*Huon(i,j,k_lev)*(t_tr(i-1,j,k_lev,1,1)+t_tr(i,j,k_lev,1,1))
        FE_ref(i,j) = 0.5_real32*Hvom(i,j,k_lev)*(t_tr(i,j-1,k_lev,1,1)+t_tr(i,j,k_lev,1,1))
      end do
    end do
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel
    call wall_time(t1)
    call gpu_kernel_horiz_tracer_flux(Istr,Iend,Jstr,Jend,N,k_lev, &
                                       t_tr,Huon,Hvom,FX_gpu,FE_gpu,Lm,Mm,NT)
    call wall_time(t2)
    t_gpu = t2 - t1

    ! Compare
    max_err = 0.0_real32
    do j = Jstr, Jend
      do i = Istr, Iend
        max_err = max(max_err, abs(FX_gpu(i,j) - FX_ref(i,j)))
        max_err = max(max_err, abs(FE_gpu(i,j) - FE_ref(i,j)))
      end do
    end do
    write(*,'(A,E10.3)') '         Max error vs CPU reference: ', max_err
    ok = (max_err < 1.0e-2_real32)

    deallocate(t_tr, Huon, Hvom, FX_gpu, FE_gpu, FX_ref, FE_ref)
  end subroutine test_horiz_tracer

  !------------------------------------------------------------------
  ! Test 4: Vertical mixing
  !------------------------------------------------------------------
  subroutine test_vert_mix(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=63, Mm=63, N=50, NT=2
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: t_tr_gpu(:,:,:,:,:), t_tr_ref(:,:,:,:,:)
    real(real32), allocatable :: Hz(:,:,:), Akt(:,:,:)
    real(real32) :: dt
    integer :: i, j, k, itrc
    real(real64) :: t1, t2
    real(real32) :: max_err

    allocate(t_tr_gpu(0:Lm+1,0:Mm+1,N,3,NT))
    allocate(t_tr_ref(0:Lm+1,0:Mm+1,N,3,NT))
    allocate(Hz(0:Lm+1,0:Mm+1,N), Akt(0:Lm+1,0:Mm+1,0:N))

    dt = 600.0_real32  ! 10-minute timestep
    Hz  = 10.0_real32
    Akt = 1.0e-4_real32  ! background diffusivity m^2/s

    ! Initial tracer profile: linear
    do k = 1, N
      t_tr_gpu(:,:,k,1,:) = 20.0_real32 - real(k,real32)*0.3_real32
      t_tr_ref(:,:,k,1,:) = t_tr_gpu(:,:,k,1,:)
    end do

    ! CPU reference: trivial (no mixing since Hz uniform)
    call wall_time(t1)
    do j = Jstr, Jend
      do i = Istr, Iend
        do itrc = 1, NT
          do k = 1, N
            t_tr_ref(i,j,k,3,itrc) = t_tr_ref(i,j,k,1,itrc)  ! no change approx
          end do
        end do
      end do
    end do
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel
    call wall_time(t1)
    call gpu_kernel_vert_mix(Istr,Iend,Jstr,Jend,N, &
                              t_tr_gpu,Hz,Akt,dt,Lm,Mm,NT)
    call wall_time(t2)
    t_gpu = t2 - t1

    ! Check: output tracer should be close to input (small diffusivity)
    max_err = 0.0_real32
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend
          max_err = max(max_err, abs(t_tr_gpu(i,j,k,3,1) - t_tr_gpu(i,j,k,1,1)))
        end do
      end do
    end do
    write(*,'(A,E10.3)') '         Max tracer change (should be small): ', max_err
    ok = (max_err < 1.0_real32)  ! less than 1 degree C change per timestep

    deallocate(t_tr_gpu, t_tr_ref, Hz, Akt)
  end subroutine test_vert_mix

  !------------------------------------------------------------------
  ! Test 5: Pressure gradient
  !------------------------------------------------------------------
  subroutine test_prsgrd(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=63, Mm=63, N=40
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: rho(:,:,:), z_r(:,:,:), Hz(:,:,:)
    real(real32), allocatable :: ru_gpu(:,:,:), rv_gpu(:,:,:)
    real(real32), allocatable :: ru_ref(:,:,:), rv_ref(:,:,:)
    real(real32) :: rho0, g
    integer :: i, j, k
    real(real64) :: t1, t2
    real(real32) :: max_err

    allocate(rho(0:Lm+1,0:Mm+1,N), z_r(0:Lm+1,0:Mm+1,N), Hz(0:Lm+1,0:Mm+1,N))
    allocate(ru_gpu(0:Lm+1,0:Mm+1,N), rv_gpu(0:Lm+1,0:Mm+1,N))
    allocate(ru_ref(0:Lm+1,0:Mm+1,N), rv_ref(0:Lm+1,0:Mm+1,N))

    rho0 = 1025.0_real32; g = 9.81_real32
    do k = 1, N
      do j = 0, Mm+1
        do i = 0, Lm+1
          rho(i,j,k) = 2.0_real32*real(k,real32)/real(N,real32) + 0.1_real32*real(i,real32)/real(Lm,real32)
          z_r(i,j,k) = -real(k,real32)*6.0_real32
          Hz(i,j,k)  = 6.0_real32
        end do
      end do
    end do
    ru_gpu = 0.0_real32; rv_gpu = 0.0_real32
    ru_ref = 0.0_real32; rv_ref = 0.0_real32

    ! CPU reference
    call wall_time(t1)
    call cpu_prsgrd_ref(Istr,Iend,Jstr,Jend,N,rho,z_r,Hz,ru_ref,rv_ref,rho0,g,Lm,Mm)
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel
    call wall_time(t1)
    call gpu_kernel_prsgrd(Istr,Iend,Jstr,Jend,N,rho,z_r,Hz,ru_gpu,rv_gpu,rho0,g,Lm,Mm)
    call wall_time(t2)
    t_gpu = t2 - t1

    ! Compare
    max_err = 0.0_real32
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend+1
          max_err = max(max_err, abs(ru_gpu(i,j,k) - ru_ref(i,j,k)))
        end do
      end do
    end do
    write(*,'(A,E10.3)') '         Max error vs CPU reference: ', max_err
    ok = (max_err < 1.0e-3_real32)

    deallocate(rho, z_r, Hz, ru_gpu, rv_gpu, ru_ref, rv_ref)
  end subroutine test_prsgrd

  subroutine cpu_prsgrd_ref(Istr,Iend,Jstr,Jend,N,rho,z_r,Hz,ru,rv,rho0,g,Lm,Mm)
    integer, intent(in) :: Istr,Iend,Jstr,Jend,N,Lm,Mm
    real(real32), intent(in) :: rho0,g
    real(real32), intent(in) :: rho(0:Lm+1,0:Mm+1,N), z_r(0:Lm+1,0:Mm+1,N)
    real(real32), intent(in) :: Hz(0:Lm+1,0:Mm+1,N)
    real(real32), intent(inout) :: ru(0:Lm+1,0:Mm+1,N), rv(0:Lm+1,0:Mm+1,N)
    integer :: i,j,k
    real(real32) :: cff,cff1
    do k = 1, N
      do j = Jstr, Jend
        do i = Istr, Iend+1
          cff  = g/rho0
          cff1 = 0.5_real32*(Hz(i,j,k)+Hz(i-1,j,k))
          ru(i,j,k) = ru(i,j,k) - cff1*(cff*rho(i,j,k)*(z_r(i,j,k)-z_r(i-1,j,k)) &
                                        +cff*rho(i-1,j,k)*(z_r(i,j,k)-z_r(i-1,j,k)))
        end do
      end do
    end do
    do k = 1, N
      do j = Jstr, Jend+1
        do i = Istr, Iend
          cff  = g/rho0
          cff1 = 0.5_real32*(Hz(i,j,k)+Hz(i,j-1,k))
          rv(i,j,k) = rv(i,j,k) - cff1*(cff*rho(i,j,k)*(z_r(i,j,k)-z_r(i,j-1,k)) &
                                        +cff*rho(i,j-1,k)*(z_r(i,j,k)-z_r(i,j-1,k)))
        end do
      end do
    end do
  end subroutine cpu_prsgrd_ref

  !------------------------------------------------------------------
  ! Test 6: 2D barotropic step
  !------------------------------------------------------------------
  subroutine test_step2d(ok, t_cpu, t_gpu)
    logical, intent(out) :: ok
    real(real64), intent(out) :: t_cpu, t_gpu
    integer, parameter :: Lm=255, Mm=255
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    real(real32), allocatable :: zeta_gpu(:,:,:), ubar_gpu(:,:,:), vbar_gpu(:,:,:)
    real(real32), allocatable :: zeta_ref(:,:,:), ubar_ref(:,:,:), vbar_ref(:,:,:)
    real(real32), allocatable :: Drhs(:,:), DUon(:,:), DVom(:,:)
    real(real32), allocatable :: rufrc(:,:), rvfrc(:,:), pm(:,:), pn(:,:)
    real(real32) :: dt2d
    integer :: i, j
    real(real64) :: t1, t2
    real(real32) :: max_err

    allocate(zeta_gpu(0:Lm+1,0:Mm+1,4), ubar_gpu(0:Lm+1,0:Mm+1,3), vbar_gpu(0:Lm+1,0:Mm+1,3))
    allocate(zeta_ref(0:Lm+1,0:Mm+1,4), ubar_ref(0:Lm+1,0:Mm+1,3), vbar_ref(0:Lm+1,0:Mm+1,3))
    allocate(Drhs(0:Lm+1,0:Mm+1), DUon(0:Lm+1,0:Mm+1), DVom(0:Lm+1,0:Mm+1))
    allocate(rufrc(0:Lm+1,0:Mm+1), rvfrc(0:Lm+1,0:Mm+1))
    allocate(pm(0:Lm+1,0:Mm+1), pn(0:Lm+1,0:Mm+1))

    dt2d = 20.0_real32
    pm = 1.0_real32/5000.0_real32; pn = 1.0_real32/5000.0_real32
    DUon = 0.5_real32; DVom = 0.3_real32
    rufrc = 0.01_real32; rvfrc = 0.008_real32
    zeta_gpu = 0.0_real32; zeta_gpu(:,:,1) = 0.1_real32
    ubar_gpu = 0.2_real32; vbar_gpu = 0.15_real32
    zeta_ref = zeta_gpu; ubar_ref = ubar_gpu; vbar_ref = vbar_gpu
    Drhs = 100.0_real32

    ! CPU reference
    call wall_time(t1)
    do j = Jstr, Jend
      do i = Istr, Iend
        zeta_ref(i,j,3) = zeta_ref(i,j,1) - dt2d*pm(i,j)*pn(i,j)* &
                           (DUon(i+1,j)-DUon(i,j)+DVom(i,j+1)-DVom(i,j))
        ubar_ref(i,j,3) = ubar_ref(i,j,1) + dt2d*rufrc(i,j)
        vbar_ref(i,j,3) = vbar_ref(i,j,1) + dt2d*rvfrc(i,j)
      end do
    end do
    call wall_time(t2)
    t_cpu = t2 - t1

    ! GPU kernel
    call wall_time(t1)
    call gpu_kernel_step2d(Istr,Iend,Jstr,Jend, &
                            zeta_gpu,ubar_gpu,vbar_gpu,Drhs, &
                            DUon,DVom,rufrc,rvfrc,pm,pn,dt2d,Lm,Mm)
    call wall_time(t2)
    t_gpu = t2 - t1

    max_err = 0.0_real32
    do j = Jstr, Jend
      do i = Istr, Iend
        max_err = max(max_err, abs(zeta_gpu(i,j,3) - zeta_ref(i,j,3)))
        max_err = max(max_err, abs(ubar_gpu(i,j,3) - ubar_ref(i,j,3)))
      end do
    end do
    write(*,'(A,E10.3)') '         Max error vs CPU reference: ', max_err
    ok = (max_err < 1.0e-4_real32)

    deallocate(zeta_gpu, ubar_gpu, vbar_gpu, zeta_ref, ubar_ref, vbar_ref)
    deallocate(Drhs, DUon, DVom, rufrc, rvfrc, pm, pn)
  end subroutine test_step2d

  !------------------------------------------------------------------
  ! Test 7: Full performance benchmark
  !------------------------------------------------------------------
  subroutine test_benchmark_full(t_cpu_total, t_gpu_total)
    real(real64), intent(out) :: t_cpu_total, t_gpu_total
    integer, parameter :: Lm=255, Mm=255, N=50, NT=2
    integer, parameter :: Istr=1, Iend=Lm, Jstr=1, Jend=Mm
    integer, parameter :: NSTEPS = 10
    real(real32), allocatable :: h(:,:), hinv(:,:), Zt_avg1(:,:)
    real(real32), allocatable :: sc_w(:), sc_r(:), Cs_w(:), Cs_r(:)
    real(real32), allocatable :: z_w(:,:,:), z_r(:,:,:), Hz(:,:,:), Hz_bak(:,:,:)
    real(real32), allocatable :: rho(:,:,:), bvf(:,:,:), t_tr(:,:,:,:,:)
    real(real32), allocatable :: FX(:,:), FE(:,:), Huon(:,:,:), Hvom(:,:,:)
    real(real32), allocatable :: ru(:,:,:), rv(:,:,:)
    real(real32) :: hc, rho0, g
    integer :: step, i, j, k
    real(real64) :: t1, t2

    write(*,'(A,I3,A,I3,A,I3,A)') '         Domain: ', Lm, 'x', Mm, 'x', N, ' points'
    write(*,'(A,I3,A)') '         Running ', NSTEPS, ' timestep iterations'

    allocate(h(0:Lm+1,0:Mm+1), hinv(0:Lm+1,0:Mm+1), Zt_avg1(0:Lm+1,0:Mm+1))
    allocate(sc_w(0:N), sc_r(N), Cs_w(0:N), Cs_r(N))
    allocate(z_w(0:Lm+1,0:Mm+1,0:N), z_r(0:Lm+1,0:Mm+1,N))
    allocate(Hz(0:Lm+1,0:Mm+1,N), Hz_bak(0:Lm+1,0:Mm+1,N))
    allocate(rho(0:Lm+1,0:Mm+1,N), bvf(0:Lm+1,0:Mm+1,0:N))
    allocate(t_tr(0:Lm+1,0:Mm+1,N,3,NT))
    allocate(FX(0:Lm+1,0:Mm+1), FE(0:Lm+1,0:Mm+1))
    allocate(Huon(0:Lm+1,0:Mm+1,N), Hvom(0:Lm+1,0:Mm+1,N))
    allocate(ru(0:Lm+1,0:Mm+1,N), rv(0:Lm+1,0:Mm+1,N))

    ! Initialize realistic ocean data
    hc = 10.0_real32; rho0 = 1025.0_real32; g = 9.81_real32
    do j = 0, Mm+1; do i = 0, Lm+1
      h(i,j) = 100.0_real32 + 50.0_real32*sin(real(i,real32)*0.05_real32)
      hinv(i,j) = 1.0_real32/(abs(h(i,j)) + hc)
      Zt_avg1(i,j) = 0.1_real32*cos(real(j,real32)*0.05_real32)
      Hz(i,j,:) = 3.0_real32; Hz_bak(i,j,:) = 3.0_real32
    end do; end do
    do k = 0, N
      sc_w(k) = real(k,real32)/real(N,real32) - 1.0_real32; Cs_w(k) = sc_w(k)
    end do
    do k = 1, N
      sc_r(k) = (real(k,real32)-0.5_real32)/real(N,real32) - 1.0_real32; Cs_r(k) = sc_r(k)
      t_tr(:,:,k,1,1) = 20.0_real32 - 15.0_real32*real(k,real32)/real(N,real32)
      t_tr(:,:,k,1,2) = 35.0_real32 - 2.0_real32*real(k,real32)/real(N,real32)
    end do
    Huon = 100.0_real32; Hvom = 80.0_real32
    ru = 0.0_real32; rv = 0.0_real32; bvf = 0.0_real32

    ! GPU warmup
    call gpu_kernel_set_depth(Istr,Iend,Jstr,Jend,N,h,hinv,Zt_avg1,Zt_avg1, &
                               sc_w,sc_r,Cs_w,Cs_r,hc,z_w,z_r,Hz,Hz_bak,Lm,Mm)

    ! Timed GPU benchmark
    call wall_time(t1)
    do step = 1, NSTEPS
      call gpu_kernel_set_depth(Istr,Iend,Jstr,Jend,N,h,hinv,Zt_avg1,Zt_avg1, &
                                 sc_w,sc_r,Cs_w,Cs_r,hc,z_w,z_r,Hz,Hz_bak,Lm,Mm)
      call gpu_kernel_rho_eos(Istr,Iend,Jstr,Jend,N,t_tr,rho,bvf, &
                               z_r,z_w,Hz,rho0,g,Lm,Mm,NT)
      call gpu_kernel_horiz_tracer_flux(Istr,Iend,Jstr,Jend,N,N/2, &
                                         t_tr,Huon,Hvom,FX,FE,Lm,Mm,NT)
      call gpu_kernel_prsgrd(Istr,Iend,Jstr,Jend,N,rho,z_r,Hz,ru,rv,rho0,g,Lm,Mm)
    end do
    call wall_time(t2)
    t_gpu_total = (t2 - t1) / real(NSTEPS, real64)

    ! CPU benchmark
    call wall_time(t1)
    do step = 1, NSTEPS
      call cpu_set_depth_ref(Istr,Iend,Jstr,Jend,N,Lm,Mm, &
                              h,hinv,Zt_avg1,hc,sc_w,sc_r,Cs_w,Cs_r, &
                              z_w,z_r,Hz,Hz_bak)
    end do
    call wall_time(t2)
    t_cpu_total = (t2 - t1) / real(NSTEPS, real64)

    write(*,'(A,F8.1,A)') '         GPU per-step time: ', t_gpu_total*1000.0_real64, ' ms'
    write(*,'(A,F8.1,A)') '         CPU set_depth time: ', t_cpu_total*1000.0_real64, ' ms'
    write(*,'(A,F6.2,A)') '         GPU all-kernels speedup: ', &
      t_cpu_total/max(t_gpu_total,1.0e-9_real64), 'x'
    write(*,'(A,F6.3,A)') '         Throughput: ', &
      real(Lm*Mm*N,real64)*1.0e-6_real64/max(t_gpu_total,1.0e-9_real64), ' Mcells/s'

    deallocate(h, hinv, Zt_avg1, sc_w, sc_r, Cs_w, Cs_r)
    deallocate(z_w, z_r, Hz, Hz_bak, rho, bvf, t_tr, FX, FE, Huon, Hvom, ru, rv)
  end subroutine test_benchmark_full

end program test_gpu_kernels
